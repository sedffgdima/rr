#include <iostream>
#include <string>
#include "block.h"

using namespace std;

class Fetch {
public:
	string uid;
	string did;
	void setUserData(string uid, string did) {
		this->uid = uid;
		this->did = did;
	};
	Block lastBlock() {
		Block block;
		//string lastBlockJson = this->get("/lastBlock?uid=" + this->uid + "&did=" + this->did);

		//std::cout << "date" << lastBlockJson << std::endl;

		//json ex1 = json::parse(lastBlockJson);
		//string date = ex1["date"];
		///////////////////////////////string date1 = ex1["uid"];


		///std::cout << "uid" << uid << std::endl;


		//block.date = date;
		//block.currentDifficulty = ex1["current_difficulty"];

		return block;
	}

	string get(string path) {
		//auto resp = muskrat::http()->follow_redirects()->get(this->origin + path);
		//return resp->body().c_str();

		return "sdfsdfsdf";
	}

private:
	string origin = "https://ykc_drop.nk-systems.ru";
};