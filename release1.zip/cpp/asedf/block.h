#ifndef Block_H
#define Block_H

#include <string>

using namespace std;

struct Block {
	string seed;
	string date;
	int currentDifficulty;
};

#endif