#include <iostream>
#include <atomic>
#include <chrono>
#include <random>
#include "block.h"
#include "sha256.h"
#include "Hash.h"

using namespace std;
using namespace std::chrono;

static string generate_did() {
	std::random_device dev;
	std::mt19937 rng(dev());
	std::uniform_int_distribution<std::mt19937::result_type> dist6(1, 9999);

	return std::to_string(dist6(rng));
}

class Miner {
public:
	string uid;
	string did;
	int id;
	std::atomic<bool>& isActive;

	Miner(std::atomic<bool>& isActiveRef) : isActive(isActiveRef), id(0) {
		this->did = generate_did();
	}

	Hash startEach() {
		for (long salt = 1;; salt++) {
			if (isActive == false) {
				Hash foundHash;
				foundHash.did = this->did;
				foundHash.hash = "";
				foundHash.salt = 0;
				return foundHash;
			}
			if (salt % 5000000 == 0) {
				auto timePoint = high_resolution_clock::now();
				auto duration = duration_cast<microseconds>(timePoint - this->lastTimePoint);
				//if (duration.count() > 5000000) {
				int newHashrate = (static_cast<float>(5000000) / duration.count()) * 1000000;
				this->lastTimePoint = timePoint;
				std::cout << "{\"type\":\"hashrate\", \"miner\":" << this->id << ", \"value\":" << newHashrate << "}" << std::endl;
				//}

				if (salt == 1000000000) {
					this->did = generate_did();
					salt = 1;
				}
			}

			auto hash = sha256(std::to_string(salt));
			bool isRelevant = chechHashDifficulty(hash);

			if (isRelevant == true) {
				Hash foundHash;
				foundHash.did = this->did;
				foundHash.hash = SHA256::toString(hash);
				foundHash.salt = salt;
				return foundHash;
			}
		}
	}

	void setLastBlock(string seed, string date, int currentDifficulty) {
		this->lastBlock.seed = seed;
		this->lastBlock.date = date;
		this->lastBlock.currentDifficulty = currentDifficulty;
	}

private:
	chrono::system_clock::time_point lastTimePoint = chrono::system_clock::now();
	Block lastBlock;

	std::array<uint8_t, 32> sha256(string salt) const {
		std::string stringToHash = this->uid + "/" + this->did + "/" + this->lastBlock.seed + "/" + this->lastBlock.date + "/" + salt;

		SHA256 sha;
		sha.update(stringToHash);
		std::array<uint8_t, 32> digest = sha.digest();

		return digest;
	};

	bool chechHashDifficulty(std::array<uint8_t, 32> hash) const {
		int count = 0;

		for (size_t i = 0; i < 32; ++i) {
			if (hash[i] == 0) {
				count += 2;
			}
			else {
				if ((hash[i] % 16 == 0) || (hash[i] < 16)) {
					++count;
				};
			}
		}

		return this->lastBlock.currentDifficulty == count;
	}
};