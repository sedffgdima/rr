#include <iostream>
#include <thread>
#include <future>
#include "block.h"
#include "Miner.cpp"
#include "Hash.h"

using namespace std;

class Workers {
public:
	Workers() : isActive(true) {}
	void add(int id) {
		std::promise<Hash> promise;
		std::future<Hash> future = promise.get_future();
		futures.push_back(std::move(future));

		std::thread t([this, promise = std::move(promise), id = std::move(id)]() mutable {
			startWorker(id, std::move(promise));
		});
		threads.push_back(std::move(t));
	}

	void listAllThreads() const {
		std::cout << "List of all threads:" << std::endl;
		for (const auto& thread : threads) {
			std::cout << "Thread ID: " << thread.get_id() << std::endl;
		}
	}

	void waitForThreadsCompletion() {
		for (auto& thread : threads) {
			thread.join();
		}
	}

	std::vector<Hash> getResults() {
		std::vector<Hash> results;
		for (auto& future : futures) {
			results.push_back(future.get());
		}
		return results;
	}

	void setLastBlock(Block lastBlock) {
		this->lastBlock = lastBlock;
	}
	
	void setUid(string uid) {
		this->uid = uid;
	}

private:
	std::vector<std::thread> threads;
	std::vector<std::future<Hash>> futures;
	std::atomic<bool> isActive;
	Block lastBlock;
	string uid;

	void startWorker(int id, std::promise<Hash>&& p) {
		Miner miner(isActive);
		miner.id = id;
		miner.uid = this->uid;
		miner.isActive = &isActive;
		miner.setLastBlock(lastBlock.seed , lastBlock.date, lastBlock.currentDifficulty);

		Hash foundHash = miner.startEach();

		p.set_value(foundHash);

		// ���������, ���������� �� ������ �����, � ������������� isActive � false
		bool expected = true;
		if (isActive.compare_exchange_strong(expected, false)) {
			//std::cout << "First worker completed. Setting isActive to false." << std::endl;
		}
	}
};