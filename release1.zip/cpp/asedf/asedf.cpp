﻿#include <chrono>
#include <string>
#include "Workers.cpp"
#include "block.h"
#include "Hash.h"

using namespace std;

int main(int argc, char* argv[])
{
	if (argc == 6) {

		string uid = argv[1];
		string seed = argv[2];
		string date = argv[3];
		int currentDifficulty = stoi(argv[4]);

		int threadsCount = stoi(argv[5]);

		Block lastBlock;
		lastBlock.seed = seed;
		lastBlock.date = date;
		lastBlock.currentDifficulty = currentDifficulty;

		Workers workers;
		workers.setUid(uid);
		workers.setLastBlock(lastBlock);

		for (int i = 0; i < threadsCount; i++) {
			workers.add(i);
		}

		workers.waitForThreadsCompletion();

		std::vector<Hash> results = workers.getResults();
		for (const auto& result : results) {
			if (result.salt > 0) {
				std::cout << "{\"type\":\"result\", \"did\":" << result.did << ", \"hash\":\"" << result.hash << "\", \"salt\":" << result.salt << "}" << std::endl;
			}
		}

		/*while (true) {
			std::this_thread::sleep_for(std::chrono::seconds(1));
		}*/
	}
	


	return EXIT_SUCCESS;
}
