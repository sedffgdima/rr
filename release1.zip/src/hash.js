const crypto = require("crypto");

const hashv1 = {
    hash: (sha256, uid, did, seed, date, salt) => sha256.copy().update(`${uid}/${did}/${seed}/${date}/${salt}`).digest("hex"),
    count: (hash) => {
        let count = 0;
        for (let hashIter = 0; hashIter < hash.length; ++hashIter) {
            if (hash[hashIter] === '0') count++;
        }
        return count;
    }
}

const hashv2 = {
    hash: (uid, did, seed, date, salt) => crypto.createHash("sha256").update(`${uid}/${did}/${seed}/${date}/${salt}`).digest("hex"),
    count: (hash, current_difficulty) => {
        let count = 0;
        for (let hashIter = 0; hashIter < hash.length; ++hashIter) {
            if ((hash.length - hashIter) * 2 < current_difficulty - count) {
                break;
            }
            if (hash[hashIter] === '0') count++;
        }
        return count;
    }
};

const hashv3 = {
    hash: (uid, did, seed, date, salt) => crypto.createHash("sha256").update(`${uid}/${did}/${seed}/${date}/${salt}`).digest(),
    count: (hash, current_difficulty) => {
        let count = 0;
        for (let hashIter = 0; hashIter < hash.length; ++hashIter) {
            if ((hash.length - hashIter) * 2 < current_difficulty - count) {
                break;
            }
            if (hash[hashIter] === 0) {
                count += 2;
            } else {
                if ((hash[hashIter] % 16 === 0) || (hash[hashIter] < 16)) {
                    ++count;
                };
            }
        }
        return count;
    }
}

module.exports = {
    hashv1,
    hashv2,
    hashv3,
}