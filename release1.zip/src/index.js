let crypto;
try {
    crypto = require("node:crypto")
} catch (error) {
    crypto = require("crypto")
}
const fetch = globalThis.fetch || require('node-fetch');
const performance = globalThis.performance || require('perf_hooks').performance;
const { hashv3, hashv1, hashv2 } = require("./hash");

let uid = "375707065";

/*
    hashFinderVariant = 1 -- полностью старый алгоритм
    hashFinderVariant = 2 -- старый алгоритм с оптимизациями
    hashFinderVariant = 3 -- новый
*/
const hashFinderVariant = 1;

let did = `${Math.ceil(Math.random() * 1000000000000)}`;

async function req(url, body = null) {
    return new Promise((resolve, reject) => {
        fetch(`https://ykc_drop.nk-systems.ru${url}`, {
            method: body ? 'POST' : 'GET',
            ...(body ? {
                body
            } : {})
        }).then(res => res.text()).then(res => resolve(res)).catch(e => {})
    })
}

(async () => {
    let hash;
    let count;
    let salt = BigInt(0);
    let old_salt = BigInt(0);
    let time;
    let t1;
    let t2;
    let t3;
    let checkLastBlockTiming = 10000;
    let lastBlock;
    let hasAsyncOperation = false;
    let sha256 = crypto.createHash("sha256");

    let hashes = {}

    console.log("uid", uid, "did", did);

    setLastBlock(JSON.parse(await req(`/lastBlock?uid=${uid}`)));
    testHashrate();

    const hashFinderAlgs = [
        [
            () => hashv1.hash(sha256, uid, did, lastBlock.seed, lastBlock.date, salt),
            () => hashv1.count(hash),
        ],
        [
            () => hashv2.hash(uid, did, lastBlock.seed, lastBlock.date, salt),
            () => hashv2.count(hash),
        ],
        [
            () => hashv3.hash(uid, did, lastBlock.seed, lastBlock.date, salt),
            () => hashv3.count(hash, lastBlock.current_difficulty),
        ]
    ];

    function setLastBlock(block) {
        lastBlock = block;

        switch (lastBlock.current_difficulty) {
            case 20:
                checkLastBlockTiming = 5000;
                break;
            case 19:
                checkLastBlockTiming = 4000;
                break;

            case 18:
                checkLastBlockTiming = 3000;
                break;
        
            default:
                checkLastBlockTiming = 10000;
                break;
        }
    }

    function testHashrate() {
        let hash;
        hasAsyncOperation = true;
        req(`/testHashrate?uid=${uid}&did=${did}`).then(testHashRate => {
            hasAsyncOperation = false;
        
            if(testHashRate.startsWith('{')) testHashRate = JSON.parse(testHashRate); else return;
            let salt

            for (salt = 0, hash;; salt++) {
                hash = crypto.createHash("sha256").update(`${uid}/${testHashRate.seed}/${testHashRate.date}/${salt}`).digest("hex");
                if (hash === testHashRate.hash) {
                    break;
                }
            }

            hasAsyncOperation = true;
            req(`/verifyHashrate?uid=${uid}&did=${did}&salt=${salt}`).then(hashrate => {
                hasAsyncOperation = false;
            })
        });
    }

    const checkLastBlockSync = () => {
        hasAsyncOperation = true;
        fetch(`https://ykc_drop.nk-systems.ru/lastBlock?uid=${uid}&did=${did}`)
            .then(res => res.json())
            .then(newLastBlock => {
                hasAsyncOperation = false;
                if (newLastBlock.seed !== lastBlock.seed) {
                    setLastBlock(newLastBlock)
                }
            }).catch(e => {})
    };

    const calculateHash = async () => {
        hash = hashFinderAlgs[hashFinderVariant - 1][0]();
    }

    const verifyHash = () => {
        // count = 0;

        count = hashFinderAlgs[hashFinderVariant - 1][1]();

        if (count > 15) {
            hashes[`${count}`] = hashes[`${count}`] ? hashes[`${count}`] +1 : 1;
        }

        if (count === lastBlock.current_difficulty) {
            console.log(count, `/verifyBlock?uid=${uid}&did=${did}&hash=${hash.toString("hex")}&difficulty=${lastBlock.current_difficulty}&seed=${lastBlock.seed}&date=${lastBlock.date}&salt=${salt}`);
            
            hasAsyncOperation = true;
            req(`/verifyBlock?uid=${uid}&did=${did}&hash=${hash.toString("hex")}&difficulty=${lastBlock.current_difficulty}&seed=${lastBlock.seed}&date=${lastBlock.date}&salt=${salt}`).then(verifyBlockResponse => {
                hasAsyncOperation = false;

                console.log("verifyBlockResponse", verifyBlockResponse);
                if (verifyBlockResponse !== '0') {
                    setLastBlock(JSON.parse(verifyBlockResponse))
                    salt = BigInt(0);
                }
            });
        }

        salt++;
    }

    t1 = performance.now();
    t2 = performance.now();
    t3 = performance.now();
    for (; ;) {
        // console.log(salt);
        if (salt % 10000n === 0n) time = performance.now();

        calculateHash();
        verifyHash();

        if ((time - t3) > 30000) {
            t3 = time;
            console.log(`Hashrate: ${(salt - old_salt) / 30n}`, "salt=", salt, "lastBlock.seed", lastBlock.seed, "\n");
            console.log("Распределение", hashes);
            old_salt = salt;
        }

        if ((time - t1) > checkLastBlockTiming) {
            t1 = time;
            checkLastBlockSync();
        }

        if ((time - t2) > 30000) {
            t2 = time;
            testHashrate();
        }

        if (hasAsyncOperation === true) {
            await new Promise(setImmediate);
        }
    }
})();
