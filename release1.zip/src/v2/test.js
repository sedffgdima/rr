const { Miner } = require("../../dist/v2/Miner");
const { Requests } = require("../../dist/v2/Requests");

const uid = "375707065";
const threads = 1;

const timeoutByDifficulty = {
    18: 3000,
    19: 4000,
    20: 5000,
    21: 7000,
    22: 15000,
}

const miner = new Miner(uid, threads);
const requests = new Requests();

miner.setLastblock({
    current_difficulty: 22,
    date: 1,
    seed: "1"
});

let currentBlock;
let lastBlockTimeout;

async function checkLastBlock() {
    const lastBlock = await requests.getLastBlock(uid);
    
    if (lastBlock) {
        if (currentBlock?.seed !== lastBlock.seed) {
            currentBlock = lastBlock;
            miner.setLastblock(currentBlock);
        }
    }

    lastBlockTimeout = setTimeout(() => {
        checkLastBlock()
    }, timeoutByDifficulty[currentBlock?.current_difficulty] ?? 5000);
}

checkLastBlock()

// const asdf = spawn("f:/projects/1/ykc-mining/cpp/out/build/x64-release/asedf/asedf.exe",["1", "1", "1", "22", "1"])
// asdf.stdout.on("data", (data) => {
//     console.log(data.toString());
// });